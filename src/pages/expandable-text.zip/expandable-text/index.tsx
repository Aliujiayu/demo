import { FC, useState, useEffect, useRef, } from 'react'
import Taro from "@tarojs/taro";
import { Text, View } from "@tarojs/components";

import "./index.scss";
export interface expandableTextTypes {
	line: string | number, // 展示多少行
	lineHeight: string | number, // 行高
	longText: String, // 文案
	useExpandSlot?: Boolean, // 自定义展开、收起布局
	expandText: String, // 自定义展开文字
	foldText: String, // 自定义收起文字
}
const ExpandableText: FC<expandableTextTypes> = (props: any) => {
	let { line, lineHeight, longText, useExpandSlot, expandText, foldText } = props;
	const textRef = useRef();

	const [collapse, setCollapse] = useState(true); // 是否处于文本收缩状态，默认是
	const [textHeight, setTextHeight] = useState(0); // 全量所占文本高度


	const lines = () => {
		let ll = 0
		if (textHeight > 0 && lineHeight > 0) {
			const actual: any = Taro.pxTransform(lineHeight)
			ll = Math.ceil(textHeight / actual.replace(/rpx/g, ''))
		}
		return ll
	}

	useEffect(() => {
		setTimeout(() => {
			setTextHeight(100);
			// 这里不管用什么方法，只要拿到
			// <Text ref={textRef} id="jj-content" className="jj-content">
			// 	{longText ? longText : ''}
			// </Text>
			// 的高度即可 setTextHeight(100);
		}, 1000)
	}, [])


	return (
		<View className="jj-expandable-text">
			<View
				className={!collapse ? 'expandable text' : 'text'}
				style={{
					'--lineheight': lineHeight + 'rpx',
					'lineHeight': lineHeight + 'rpx',
					'maxHeight': collapse ? (lineHeight * line) + 'rpx' : '1000px'
				}}
			>
				{lines() > line &&
					<View
						onClick={() => {
							setCollapse(!collapse)
							console.log(collapse);
						}}
						className={(!collapse || line > 1) ? 'clearboth btn' : 'btn'}
						style={{ 'height': lineHeight + 'rpx' }}>
						{
							useExpandSlot ?
								<>
									{collapse ?
										<slot name="expand-icon"></slot> :
										<slot name="fold-icon"></slot>}
								</> :
								<Text className="opt-hint">{collapse ? expandText : foldText}</Text>
						}
					</View>
				}
				<Text ref={textRef} id="jj-content" className="jj-content">
					{longText ? longText : ''}
				</Text>
			</View>
		</View>
	);
}

export default ExpandableText;